<?php
$x = "hello" ;
$y = "sir";
echo($x + $y);

$Phone = $_POST['phone'];
$Password = $_POST['Password'];
$Name = $_POST['Name'];
$telegram = $_POST['telegram'];
//DATABASE CONNECTION
$conn = new mysqli('localhost','root','root','esmer');
if ($conn->connect_error) {
  die('connection failed : ' .$conn->connect_error );
}else {
  $stmt = $conn->prepare("insert into register(phone, password, name, telegram)values(?, ?, ?, ?)");
  $stmt->bind_param('isss $Phone, $Password, $Name, $telegram');
  $stmt->execute();
  echo("Successfully registered");
  $stmt->close();
  $conn->close();
}


?>
